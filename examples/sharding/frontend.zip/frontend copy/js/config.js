var config = {
	"accessKeyId": "AKIAIOE3CR7LCXUUF7HA", 
	"secretAccessKey": "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",
    "region": "us-east-1"
}

export {config}